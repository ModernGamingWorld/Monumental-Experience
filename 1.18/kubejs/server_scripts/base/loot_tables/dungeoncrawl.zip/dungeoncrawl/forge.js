onEvent('server.datapack.high_priority', event => {
    let loot_table = {
        pools: [{
                name: "guaranteed_coal",
                rolls: {
                    min: 1,
                    max: 2
                },
                entries: [{
                    type: "item",
                    name: "mysticalagriculture:coal_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }]
                }]
            },
            {
                name: "forge",
                rolls: {
                    min: 2,
                    max: 4
                },
                entries: [{
                        type: "item",
                        name: "mysticalagriculture:iron_essence",
                        functions: [{
                            function: "set_count",
                            count: {
                                min: 2,
                                max: 4
                            }
                        }]
                    },
                    {
                        type: "item",
                        name: "minecraft:chainmail_helmet",
                        functions: [{
                            function: "enchant_with_levels",
                            levels: 5
                        }]
                    },
                    {
                        type: "item",
                        name: "minecraft:chainmail_chestplate",
                        functions: [{
                            function: "enchant_with_levels",
                            levels: 5
                        }]
                    },
                    {
                        type: "item",
                        name: "minecraft:chainmail_leggings",
                        functions: [{
                            function: "enchant_with_levels",
                            levels: 5
                        }]
                    },
                    {
                        type: "item",
                        name: "minecraft:chainmail_boots",
                        functions: [{
                            function: "enchant_with_levels",
                            levels: 5
                        }]
                    },
                    {
                        type: "item",
                        name: "minecraft:iron_block"
                    },
                    {
                        type: "item",
                        name: "immersiveengineering:circuit_board"
                    },
                    {
                        type: "item",
                        name: "minecraft:smithing_table"
                    },
                    {
                        type: "item",
                        name: "minecraft:iron_sword"
                    },
                    {
                        type: "item",
                        name: "minecraft:air",
                        functions: [{
                            function: "dungeoncrawl:random_item",
                            loot_level: 1
                        }]
                    }
                ]
            }
        ]
    }
    event.addJson(`dungeoncrawl:loot_tables/chests/forge.json`, loot_table);
});