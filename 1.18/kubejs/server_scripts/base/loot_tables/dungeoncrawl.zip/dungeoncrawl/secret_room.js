onEvent('server.datapack.high_priority', (event) => {
    let loot_table = {
        pools: [{
            name: "secret_room",
            rolls: {
                min: 8,
                max: 8
            },
            entries: [{
                    type: "item",
                    name: "minecraft:cobweb",
                    weight: 9,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:emerald_essence",
                    weight: 6,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 2
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:lapis_lazuli_essence",
                    weight: 6,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:book",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 12
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:map",
                    weight: 3
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_13",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_cat",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_blocks",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_chirp",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_far",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_mall",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_mellohi",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_stal",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_strad",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_ward",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_11",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_wait",
                    weight: 1
                }
            ]
        }]
    };
    event.addJson(`dungeoncrawl:loot_tables/chests/secret_room.json`, loot_table);
});