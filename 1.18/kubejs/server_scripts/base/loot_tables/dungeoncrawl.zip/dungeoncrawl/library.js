onEvent('server.datapack.high_priority', (event) => {
            let loot_table = {
                pools: [{
                        name: "library",
                        rolls: {
                            min: 8,
                            max: 14
                        },
                        entries: [{
                                type: "item",
                                name: "minecraft:book",
                                weight: 3,
                                functions: [{
                                    function: "set_count",
                                    count: {
                                        min: 3,
                                        max: 6
                                    }
                                }]
                            },
                            {
                                type: "item",
                                name: "mysticalagriculture:squid_essence",
                                weight: 1,
                                functions: [{
                                    function: "set_count",
                                    count: {
                                        min: 1,
                                        max: 5
                                    }
                                }]
                            },
                            {
                                type: "item",
                                name: "minecraft:smithing_table",
                                weight: 1,
                                functions: [{
                                    function: "set_count",
                                    count: {
                                        min: 1,
                                        max: 1
                                    }
                                }]
                            },
                            {
                                type: "item",
                                name: "mysticalagriculture:chicken_essence",
                                weight: 2,
                                functions: [{
                                    function: "set_count",
                                    count: {
                                        min: 2,
                                        max: 4
                                    }
                                }]
                            },
                            {
                                type: "item",
                                name: "minecraft:writable_book",
                                weight: 2,
                                functions: [{
                                    function: "set_count",
                                    count: {
                                        min: 3,
                                        max: 6
                                    }
                                }]
                            },
                            {
                                type: "item",
                                name: "minecraft:cobweb",
                                weight: 6,
                                functions: [{
                                    function: "set_count",
                                    count: {
                                        min: 8,
                                        max: 14
                                    }
                                }]
                            },
                            {
                                type: "item",
                                name: "minecraft:book",
                                weight: 5,
                                functions: [{
                                    function: "dungeoncrawl:enchanted_book",
                                    loot_level: 3
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
    event.addJson(`dungeoncrawl:loot_tables/chests/library.json`, loot_table);
    });