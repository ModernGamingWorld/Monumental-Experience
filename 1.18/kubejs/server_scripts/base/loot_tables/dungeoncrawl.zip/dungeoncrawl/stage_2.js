onEvent('server.datapack.high_priority', (event) => {
    let loot_table = {
        pools: [{
            name: "dungeon_chest_stage_2",
            rolls: {
                min: 7,
                max: 10
            },
            entries: [{
                    type: "item",
                    name: "minecraft:apple",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:potato",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:baked_potato",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:carrot",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:coal_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }],
                    weight: 3
                },
                {
                    type: "item",
                    name: "mysticalagriculture:iron_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }],
                    weight: 2
                },
                {
                    type: "item",
                    name: "mysticalagriculture:chicken_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }],
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:cobweb",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }],
                    weight: 4
                },
                {
                    type: "item",
                    name: "mysticalagriculture:skeleton_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }],
                    weight: 4
                },
                {
                    type: "item",
                    name: "mysticalagriculture:zombie_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }],
                    weight: 5
                },
                {
                    type: "item",
                    name: "minecraft:iron_sword",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:iron_axe",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:golden_apple",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:arrow",
                    weight: 9,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 9
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_13",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_cat",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:name_tag",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:book",
                    weight: 2,
                    functions: [{
                        function: "enchant_with_levels",
                        levels: 15,
                        treasure: true
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:crossbow",
                    weight: 1
                },
                {
                    type: "item",
                    name: "mysticalagriculture:slime_essence",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:torch",
                    weight: 6,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:brown_mushroom",
                    weight: 7,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:red_mushroom",
                    weight: 7,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:bowl",
                    weight: 7
                },
                {
                    type: "item",
                    name: "minecraft:clock",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:compass",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:fermented_spider_eye",
                    weight: 3
                },
                {
                    type: "item",
                    name: "minecraft:spider_eye",
                    weight: 6,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:stick",
                    weight: 10,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:chicken_essence",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:paper",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 6
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:sugar_cane",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 5
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:bone_meal",
                    weight: 4,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:gold_nugget",
                    weight: 6,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:iron_nugget",
                    weight: 5,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:clay_ball",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:flint",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:spider_essence",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:creeper_essence",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:squid_essence",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:tnt",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:glass_bottle",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 5
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:melon",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:pumpkin",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:dead_bush",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:chicken_essence",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:brick",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:carrot_on_a_stick",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:minecart",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:tnt_minecart",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:cauldron",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:map",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:rabbit_hide",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:phantom_membrane",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:iron_horse_armor",
                    weight: 2
                },
                {
                    type: "item",
                    name: "mysticalagriculture:enderman_essence",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:shield",
                    weight: 4,
                    functions: [{
                        function: "dungeoncrawl:shield",
                        loot_level: 2
                    }]
                }
            ]
        }]
    }
    event.addJson(`dungeoncrawl:loot_tables/chests/stage_2.json`, loot_table);
});