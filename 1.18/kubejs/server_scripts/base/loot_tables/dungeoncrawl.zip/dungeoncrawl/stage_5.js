onEvent('server.datapack.high_priority', (event) => {
    let loot_table = {
        pools: [{
            name: "dungeon_chest_stage_5",
            rolls: {
                min: 7,
                max: 10
            },
            entries: [{
                    type: "item",
                    name: "mysticalagriculture:coal_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 5,
                            max: 10
                        }
                    }],
                    weight: 4
                },
                {
                    type: "item",
                    name: "mysticalagriculture:iron_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 5,
                            max: 10
                        }
                    }],
                    weight: 8
                },
                {
                    type: "item",
                    name: "mysticalagriculture:gold_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 5,
                            max: 10
                        }
                    }],
                    weight: 6
                },
                {
                    type: "item",
                    name: "mysticalagriculture:diamond_essence",
                    weight: 2
                },
                {
                    type: "item",
                    name: "mysticalagriculture:skeleton_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 6
                        }
                    }],
                    weight: 6
                },
                {
                    type: "item",
                    name: "mysticalagriculture:zombie_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 6
                        }
                    }],
                    weight: 6
                },
                {
                    type: "item",
                    name: "minecraft:golden_apple",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:enchanted_golden_apple",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_13",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_cat",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:name_tag",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:book",
                    weight: 3,
                    functions: [{
                        function: "enchant_with_levels",
                        levels: 30,
                        treasure: true
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:torch",
                    weight: 6,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 5
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:lapis_lazuli_essence",
                    weight: 4,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:fermented_spider_eye",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:spider_eye",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:stick",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:chicken_essence",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 6
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:gold_nugget",
                    weight: 6,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 6,
                            max: 9
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:iron_nugget",
                    weight: 4,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 5,
                            max: 10
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:spider_essence",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:creeper_essence",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 6
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:tnt",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:glass_bottle",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 5
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:melon",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:pumpkin",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:dead_bush",
                    weight: 4,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:minecart",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:tnt_minecart",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:cauldron",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:map",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:diamond_horse_armor",
                    weight: 3
                },
                {
                    type: "item",
                    name: "mysticalagriculture:enderman_essence",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:shield",
                    weight: 6,
                    functions: [{
                        function: "dungeoncrawl:shield",
                        loot_level: 5
                    }]
                }
            ]
        }]
    }
    event.addJson(`dungeoncrawl:loot_tables/chests/stage_5.json`, loot_table);
});