onEvent('server.datapack.high_priority', (event) => {
    let loot_table = {
        pools: [{
            name: "dungeon_chest_stage_4",
            rolls: {
                min: 7,
                max: 10
            },
            entries: [{
                    type: "item",
                    name: "mysticalagriculture:coal_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 6
                        }
                    }],
                    weight: 5
                },
                {
                    type: "item",
                    name: "mysticalagriculture:iron_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }],
                    weight: 8
                },
                {
                    type: "item",
                    name: "mysticalagriculture:gold_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }],
                    weight: 6
                },
                {
                    type: "item",
                    name: "minecraft:arrow",
                    weight: 7,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 8
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:diamond_essence",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:cobweb",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }],
                    weight: 6
                },
                {
                    type: "item",
                    name: "mysticalagriculture:skeleton_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }],
                    weight: 10
                },
                {
                    type: "item",
                    name: "mysticalagriculture:zombie_essence",
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 6
                        }
                    }],
                    weight: 8
                },
                {
                    type: "item",
                    name: "minecraft:iron_axe",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:saddle",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:golden_apple",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:enchanted_golden_apple",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_13",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:music_disc_cat",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:name_tag",
                    weight: 3
                },
                {
                    type: "item",
                    name: "minecraft:book",
                    weight: 3,
                    functions: [{
                        function: "enchant_with_levels",
                        levels: 30,
                        treasure: true
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:torch",
                    weight: 8,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:lapis_lazuli_essence",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:bowl",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:fermented_spider_eye",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:spider_eye",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:stick",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 4,
                            max: 8
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:chicken_essence",
                    weight: 2,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:gold_nugget",
                    weight: 5,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 6,
                            max: 12
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:iron_nugget",
                    weight: 5,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 5,
                            max: 10
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:spider_essence",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 7
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:creeper_essence",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 6
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:tnt",
                    weight: 1,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 3
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:glass_bottle",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 1,
                            max: 5
                        }
                    }]
                },
                {
                    type: "item",
                    name: "mysticalagriculture:slime_essence",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 6
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:carrot_on_a_stick",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:minecart",
                    weight: 2
                },
                {
                    type: "item",
                    name: "minecraft:tnt_minecart",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:cauldron",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:map",
                    weight: 1
                },
                {
                    type: "item",
                    name: "minecraft:phantom_membrane",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 3,
                            max: 5
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:diamond_horse_armor",
                    weight: 3
                },
                {
                    type: "item",
                    name: "mysticalagriculture:enderman_essence",
                    weight: 3,
                    functions: [{
                        function: "set_count",
                        count: {
                            min: 2,
                            max: 4
                        }
                    }]
                },
                {
                    type: "item",
                    name: "minecraft:shield",
                    weight: 6,
                    functions: [{
                        function: "dungeoncrawl:shield",
                        loot_level: 4
                    }]
                }
            ]
        }]
    }
    event.addJson(`dungeoncrawl:loot_tables/chests/stage_4.json`, loot_table);
});